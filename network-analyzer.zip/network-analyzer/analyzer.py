"""
Network Packet Analyzer Core Module
Contains the machine learning algorithms for anomaly detection
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from collections import Counter
import warnings
warnings.filterwarnings('ignore')

# Try to import pyshark, but provide fallback for demo mode
try:
    import pyshark
    PYSHARK_AVAILABLE = True
except ImportError:
    PYSHARK_AVAILABLE = False
    print("Warning: pyshark not installed. Running in demo mode.")

def extract_features(pcap_file):
    """
    Extract features from PCAP file using pyshark
    """
    if not PYSHARK_AVAILABLE:
        # Return demo data if pyshark is not available
        return generate_demo_data()
    
    try:
        cap = pyshark.FileCapture(pcap_file, use_json=True, include_raw=False)
        data = []
        
        for packet in cap:
            try:
                # Get protocol
                protocol = packet.highest_layer if hasattr(packet, 'highest_layer') else 'UNKNOWN'
                
                # Skip specific Layer 2 protocols
                if protocol in ['STP', 'ARP', 'CDP', 'LLDP']:
                    continue
                
                # Get packet length
                length = int(packet.length) if hasattr(packet, 'length') else 0
                
                # Get source and destination addresses
                if hasattr(packet, 'ip'):
                    src_ip = packet.ip.src
                    dst_ip = packet.ip.dst
                elif hasattr(packet, 'ipv6'):
                    src_ip = packet.ipv6.src
                    dst_ip = packet.ipv6.dst
                else:
                    src_ip = 'N/A'
                    dst_ip = 'N/A'
                
                # Get ports
                src_port = 'N/A'
                dst_port = 'N/A'
                if hasattr(packet, 'tcp'):
                    src_port = packet.tcp.srcport if hasattr(packet.tcp, 'srcport') else 'N/A'
                    dst_port = packet.tcp.dstport if hasattr(packet.tcp, 'dstport') else 'N/A'
                elif hasattr(packet, 'udp'):
                    src_port = packet.udp.srcport if hasattr(packet.udp, 'srcport') else 'N/A'
                    dst_port = packet.udp.dstport if hasattr(packet.udp, 'dstport') else 'N/A'
                
                # Get timestamp
                timestamp = float(packet.sniff_timestamp) if hasattr(packet, 'sniff_timestamp') else 0
                
                # Check for TCP flags
                retransmission = False
                reset_flag = False
                if hasattr(packet, 'tcp'):
                    retransmission = hasattr(packet.tcp, 'analysis_retransmission')
                    if hasattr(packet.tcp, 'flags_reset'):
                        reset_flag = packet.tcp.flags_reset == '1'
                
                # Add to data
                data.append([
                    protocol, length, src_ip, dst_ip, src_port, dst_port,
                    timestamp, retransmission, reset_flag
                ])
                
            except Exception as e:
                # Skip packets that cause errors
                continue
        
        cap.close()
        
        # Create DataFrame
        columns = ['Protocol', 'Length', 'Src_Address', 'Dst_Address',
                   'Src_Port', 'Dst_Port', 'Timestamp', 'Retransmission', 'Reset_Flag']
        
        df = pd.DataFrame(data, columns=columns)
        return df
        
    except Exception as e:
        print(f"Error extracting features: {e}")
        return generate_demo_data()

def detect_anomalies(data):
    """
    Detect anomalies using Isolation Forest algorithm
    """
    if len(data) < 10:
        # Not enough data for meaningful analysis
        data['Anomaly'] = 1  # Mark all as normal
        data['Anomaly_Type'] = 'Insufficient Data'
        return data
    
    try:
        # Prepare features for anomaly detection
        features = data[['Length', 'Timestamp']].copy()
        
        # Handle missing values
        features = features.fillna(features.mean())
        
        # Normalize features
        scaler = StandardScaler()
        scaled_features = scaler.fit_transform(features)
        
        # Apply Isolation Forest
        contamination = min(0.1, max(0.01, len(data) / 10000))  # Dynamic contamination
        model = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=100,
            max_samples='auto'
        )
        
        data['Anomaly'] = model.fit_predict(scaled_features)
        
        # Mark anomalies (-1) and normal (1)
        data['Anomaly'] = data['Anomaly'].apply(lambda x: -1 if x == -1 else 1)
        
        # Classify anomaly types
        data['Anomaly_Type'] = 'Normal'
        
        # Mark known anomaly types
        anomalies_mask = data['Anomaly'] == -1
        
        # Retransmissions
        retrans_mask = anomalies_mask & data['Retransmission']
        data.loc[retrans_mask, 'Anomaly_Type'] = 'Retransmission'
        
        # Reset flags
        reset_mask = anomalies_mask & data['Reset_Flag']
        data.loc[reset_mask, 'Anomaly_Type'] = 'Reset Flag'
        
        # High packet length (above 1500 bytes)
        length_mask = anomalies_mask & (data['Length'] > 1500)
        data.loc[length_mask, 'Anomaly_Type'] = 'High Packet Length'
        
        # High latency (based on timestamp outliers)
        if len(data) > 100:
            time_q3 = data['Timestamp'].quantile(0.75)
            time_iqr = data['Timestamp'].quantile(0.75) - data['Timestamp'].quantile(0.25)
            latency_threshold = time_q3 + 1.5 * time_iqr
            latency_mask = anomalies_mask & (data['Timestamp'] > latency_threshold)
            data.loc[latency_mask, 'Anomaly_Type'] = 'High Latency'
        
        # Unexpected protocols
        common_protocols = set(data['Protocol'].value_counts().head(5).index)
        protocol_mask = anomalies_mask & ~data['Protocol'].isin(common_protocols)
        data.loc[protocol_mask, 'Anomaly_Type'] = 'Unexpected Protocol'
        
        # Malformed packets (missing addresses)
        malformed_mask = anomalies_mask & ((data['Src_Address'] == 'N/A') | (data['Dst_Address'] == 'N/A'))
        data.loc[malformed_mask, 'Anomaly_Type'] = 'Malformed Packet'
        
        # Mark remaining anomalies as 'Other'
        other_mask = anomalies_mask & (data['Anomaly_Type'] == 'Normal')
        data.loc[other_mask, 'Anomaly_Type'] = 'Other'
        
        return data
        
    except Exception as e:
        print(f"Error in anomaly detection: {e}")
        data['Anomaly'] = 1
        data['Anomaly_Type'] = 'Error'
        return data

def generate_demo_data():
    """
    Generate demo data for testing when pyshark is not available
    """
    np.random.seed(42)
    
    # Generate synthetic data
    n_samples = 1000
    protocols = ['TCP', 'UDP', 'HTTP', 'DNS', 'TLS', 'ICMP']
    
    data = {
        'Protocol': np.random.choice(protocols, n_samples, p=[0.4, 0.3, 0.1, 0.1, 0.05, 0.05]),
        'Length': np.random.exponential(500, n_samples).astype(int),
        'Src_Address': [f"192.168.1.{np.random.randint(1, 255)}" for _ in range(n_samples)],
        'Dst_Address': [f"10.0.0.{np.random.randint(1, 255)}" for _ in range(n_samples)],
        'Src_Port': np.random.choice([80, 443, 53, 22, 3389, 8080], n_samples),
        'Dst_Port': np.random.choice([80, 443, 53, 22, 3389, 8080], n_samples),
        'Timestamp': np.cumsum(np.random.exponential(0.1, n_samples)),
        'Retransmission': np.random.choice([True, False], n_samples, p=[0.02, 0.98]),
        'Reset_Flag': np.random.choice([True, False], n_samples, p=[0.01, 0.99])
    }
    
    df = pd.DataFrame(data)
    
    # Add some anomalies
    anomaly_indices = np.random.choice(n_samples, 50, replace=False)
    df.loc[anomaly_indices, 'Length'] *= 3  # Large packets
    df.loc[anomaly_indices[:10], 'Retransmission'] = True
    df.loc[anomaly_indices[10:20], 'Reset_Flag'] = True
    
    return df

# Export functions
__all__ = ['extract_features', 'detect_anomalies']