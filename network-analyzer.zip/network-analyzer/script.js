document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const fileInput = document.getElementById('fileInput');
    const dropArea = document.getElementById('dropArea');
    const fileInfo = document.getElementById('fileInfo');
    const fileName = document.getElementById('fileName');
    const fileSize = document.getElementById('fileSize');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const statusIndicator = document.querySelector('.status-dot');
    const statusText = document.getElementById('statusText');
    const totalPackets = document.getElementById('totalPackets');
    const anomaliesDetected = document.getElementById('anomaliesDetected');
    const normalPackets = document.getElementById('normalPackets');
    const anomalyRate = document.getElementById('anomalyRate');
    const anomalyList = document.getElementById('anomalyList');
    const chartContainer = document.getElementById('chartContainer');
    const protocolList = document.getElementById('protocolList');
    const topSourceIPs = document.getElementById('topSourceIPs');
    const downloadSection = document.getElementById('downloadSection');
    const downloadCSV = document.getElementById('downloadCSV');
    const downloadJSON = document.getElementById('downloadJSON');
    const downloadReport = document.getElementById('downloadReport');
    const progressModal = document.getElementById('progressModal');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const packetsProcessed = document.getElementById('packetsProcessed');
    const timeElapsed = document.getElementById('timeElapsed');

    let selectedFile = null;
    let currentAnalysisData = null;
    let analysisStartTime = null;

    // Initialize drag and drop
    initializeDragAndDrop();

    // Initialize event listeners
    initializeEventListeners();

    function initializeDragAndDrop() {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, unhighlight, false);
        });

        dropArea.addEventListener('drop', handleDrop, false);
        dropArea.addEventListener('click', () => fileInput.click());
    }

    function initializeEventListeners() {
        fileInput.addEventListener('change', handleFileSelect);
        analyzeBtn.addEventListener('click', startAnalysis);
        
        downloadCSV.addEventListener('click', () => downloadData('csv'));
        downloadJSON.addEventListener('click', () => downloadData('json'));
        downloadReport.addEventListener('click', generateReport);
    }

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight() {
        dropArea.classList.add('drag-over');
    }

    function unhighlight() {
        dropArea.classList.remove('drag-over');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        handleFiles(files);
    }

    function handleFiles(files) {
        if (files.length === 0) return;
        
        const file = files[0];
        
        // Validate file type
        const validTypes = ['.pcap', '.pcapng'];
        const fileExt = '.' + file.name.split('.').pop().toLowerCase();
        
        if (!validTypes.includes(fileExt)) {
            showError('Invalid file type. Please select a .pcap or .pcapng file.');
            return;
        }

        if (file.size > 100 * 1024 * 1024) { // 100MB limit
            showError('File size exceeds 100MB limit. Please select a smaller file.');
            return;
        }

        selectedFile = file;
        updateFileInfo(file);
        analyzeBtn.disabled = false;
    }

    function updateFileInfo(file) {
        fileName.textContent = file.name;
        fileSize.textContent = formatFileSize(file.size);
        fileInfo.style.display = 'block';
        updateStatus('Ready to analyze', 'complete');
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    async function startAnalysis() {
        if (!selectedFile) return;

        analysisStartTime = Date.now();
        updateStatus('Uploading file...', 'analyzing');
        showProgressModal();

        try {
            // Create FormData
            const formData = new FormData();
            formData.append('file', selectedFile);

            // Update progress
            updateProgress(10, 'Extracting packet data...');

            // Send to backend
            const response = await fetch('http://localhost:5000/analyze', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }

            updateProgress(50, 'Detecting anomalies...');
            const data = await response.json();

            if (data.error) {
                throw new Error(data.error);
            }

            updateProgress(90, 'Generating visualizations...');
            await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate processing

            currentAnalysisData = data;
            displayResults(data);
            
            updateProgress(100, 'Analysis complete!');
            updateStatus('Analysis Complete', 'complete');
            
            // Hide modal after delay
            setTimeout(() => {
                hideProgressModal();
                downloadSection.style.display = 'block';
            }, 1000);

        } catch (error) {
            console.error('Analysis error:', error);
            hideProgressModal();
            updateStatus('Analysis Failed', 'error');
            showError(`Analysis failed: ${error.message}`);
            
            // Fallback to mock data
            displayMockResults();
        }
    }

    function updateProgress(percent, message) {
        progressFill.style.width = `${percent}%`;
        progressText.textContent = message;
        
        const elapsedSeconds = Math.floor((Date.now() - analysisStartTime) / 1000);
        timeElapsed.textContent = `${elapsedSeconds}s`;
        
        if (currentAnalysisData) {
            packetsProcessed.textContent = currentAnalysisData.total_packets.toLocaleString();
        }
    }

    function showProgressModal() {
        progressModal.style.display = 'flex';
        progressFill.style.width = '0%';
        packetsProcessed.textContent = '0';
        timeElapsed.textContent = '0s';
    }

    function hideProgressModal() {
        progressModal.style.display = 'none';
    }

    function updateStatus(text, status) {
        statusText.textContent = text;
        statusIndicator.className = 'status-dot ' + status;
    }

    function displayResults(data) {
        // Update statistics
        totalPackets.textContent = data.total_packets.toLocaleString();
        anomaliesDetected.textContent = data.anomaly_count;
        normalPackets.textContent = data.normal_packets.toLocaleString();
        anomalyRate.textContent = data.anomaly_rate.toFixed(2) + '%';

        // Update protocol distribution
        updateProtocolList(data.protocol_distribution || {});

        // Update anomaly list
        updateAnomalyList(data.anomaly_breakdown || {});

        // Update top IPs
        updateTopIPs(data.top_source_ips || []);

        // Update chart
        updateChart(data.anomaly_breakdown || {});
    }

    function updateProtocolList(protocols) {
        protocolList.innerHTML = '';
        
        if (Object.keys(protocols).length === 0) {
            protocolList.innerHTML = '<div class="placeholder-small">No protocol data available</div>';
            return;
        }

        const sortedProtocols = Object.entries(protocols)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10); // Show top 10

        sortedProtocols.forEach(([protocol, count]) => {
            const protocolItem = document.createElement('div');
            protocolItem.className = 'protocol-item';
            protocolItem.innerHTML = `
                <div class="protocol-name">
                    <i class="fas fa-network-wired"></i>
                    ${protocol}
                </div>
                <div class="protocol-count">${count}</div>
            `;
            protocolList.appendChild(protocolItem);
        });
    }

    function updateAnomalyList(anomalies) {
        anomalyList.innerHTML = '';
        
        if (Object.keys(anomalies).length === 0) {
            anomalyList.innerHTML = `
                <div class="placeholder">
                    <i class="fas fa-check-circle"></i>
                    <p>No anomalies detected</p>
                </div>
            `;
            return;
        }

        const anomalyIcons = {
            'Retransmission': 'fas fa-redo',
            'Reset Flag': 'fas fa-flag',
            'High Latency': 'fas fa-clock',
            'Unexpected Protocol': 'fas fa-question-circle',
            'Malformed Packet': 'fas fa-exclamation-triangle',
            'High Packet Length': 'fas fa-ruler',
            'Other': 'fas fa-exclamation-circle'
        };

        const anomalyDescriptions = {
            'Retransmission': 'Packet retransmission detected',
            'Reset Flag': 'TCP reset flag observed',
            'High Latency': 'Unusually high network latency',
            'Unexpected Protocol': 'Unexpected or unknown protocol',
            'Malformed Packet': 'Malformed packet structure',
            'High Packet Length': 'Exceptionally large packet size',
            'Other': 'Other type of anomaly'
        };

        Object.entries(anomalies).forEach(([type, count]) => {
            const anomalyItem = document.createElement('div');
            anomalyItem.className = 'anomaly-item';
            anomalyItem.innerHTML = `
                <div class="anomaly-icon">
                    <i class="${anomalyIcons[type] || 'fas fa-exclamation-circle'}"></i>
                </div>
                <div class="anomaly-content">
                    <h4>${type}</h4>
                    <p>${anomalyDescriptions[type] || 'Anomaly detected'} - ${count} packet${count !== 1 ? 's' : ''}</p>
                </div>
                <span class="anomaly-badge badge-${type.toLowerCase().replace(/\s+/g, '-')}">${count}</span>
            `;
            anomalyList.appendChild(anomalyItem);
        });
    }

    function updateTopIPs(ips) {
        topSourceIPs.innerHTML = '';
        
        if (ips.length === 0) {
            topSourceIPs.innerHTML = '<div class="placeholder-small">No IP data available</div>';
            return;
        }

        ips.slice(0, 5).forEach(([ip, count]) => {
            const ipItem = document.createElement('div');
            ipItem.className = 'ip-item';
            ipItem.innerHTML = `
                <span class="ip-address">${ip}</span>
                <span class="ip-count">${count}</span>
            `;
            topSourceIPs.appendChild(ipItem);
        });
    }

    function updateChart(anomalies) {
        const anomaliesArray = Object.entries(anomalies);
        
        if (anomaliesArray.length === 0) {
            chartContainer.innerHTML = `
                <div class="chart-placeholder">
                    <i class="fas fa-chart-bar"></i>
                    <p>No anomalies to display</p>
                </div>
            `;
            return;
        }

        const colors = {
            'Retransmission': '#ff9800',
            'Reset Flag': '#f44336',
            'High Latency': '#4caf50',
            'Unexpected Protocol': '#9c27b0',
            'Malformed Packet': '#795548',
            'High Packet Length': '#ff5722',
            'Other': '#607d8b'
        };

        const maxCount = Math.max(...anomaliesArray.map(([_, count]) => count));
        
        chartContainer.innerHTML = `
            <div style="height: 300px; padding: 20px; display: flex; flex-direction: column;">
                <div style="display: flex; align-items: flex-end; height: 200px; gap: 10px; margin-bottom: 20px;">
                    ${anomaliesArray.map(([type, count]) => {
                        const height = (count / maxCount) * 150;
                        const color = colors[type] || '#4361ee';
                        return `
                            <div style="flex: 1; text-align: center;">
                                <div style="position: relative;">
                                    <div style="height: ${height}px; 
                                                background: linear-gradient(to top, ${color}, ${color}80); 
                                                border-radius: 8px 8px 0 0; 
                                                transition: height 0.3s ease;">
                                    </div>
                                    <div style="position: absolute; top: -25px; left: 0; right: 0; 
                                                text-align: center; font-weight: bold; color: #333;">
                                        ${count}
                                    </div>
                                </div>
                                <div style="font-size: 12px; color: #666; margin-top: 10px; 
                                            overflow: hidden; text-overflow: ellipsis;">
                                    ${type}
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
                <div style="text-align: center; color: #666; font-size: 14px; margin-top: auto;">
                    Anomaly Distribution by Type
                </div>
            </div>
        `;
    }

    function displayMockResults() {
        const mockData = {
            total_packets: 3421,
            normal_packets: 3120,
            anomaly_count: 301,
            anomaly_rate: 8.8,
            protocol_distribution: {
                'TCP': 1420,
                'UDP': 980,
                'HTTP': 520,
                'DNS': 210,
                'TLS': 190,
                'ICMP': 101
            },
            anomaly_breakdown: {
                'Retransmission': 128,
                'High Latency': 85,
                'Reset Flag': 45,
                'Unexpected Protocol': 28,
                'Malformed Packet': 15
            },
            top_source_ips: [
                ['192.168.1.100', 420],
                ['10.0.0.5', 380],
                ['172.16.0.23', 310],
                ['192.168.1.50', 290],
                ['10.0.0.12', 210]
            ]
        };
        
        displayResults(mockData);
        downloadSection.style.display = 'block';
    }

    function downloadData(format) {
        if (!currentAnalysisData) {
            showError('No analysis data available to download');
            return;
        }

        let content, mimeType, filename;
        
        if (format === 'csv') {
            // Convert to CSV format
            const csvData = [
                ['Category', 'Value'],
                ['Total Packets', currentAnalysisData.total_packets],
                ['Normal Packets', currentAnalysisData.normal_packets],
                ['Anomaly Count', currentAnalysisData.anomaly_count],
                ['Anomaly Rate', currentAnalysisData.anomaly_rate + '%'],
                [],
                ['Anomaly Type', 'Count']
            ];
            
            Object.entries(currentAnalysisData.anomaly_breakdown || {}).forEach(([type, count]) => {
                csvData.push([type, count]);
            });
            
            content = csvData.map(row => row.join(',')).join('\n');
            mimeType = 'text/csv';
            filename = 'network_analysis.csv';
        } else {
            content = JSON.stringify(currentAnalysisData, null, 2);
            mimeType = 'application/json';
            filename = 'network_analysis.json';
        }

        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function generateReport() {
        if (!currentAnalysisData) {
            showError('No analysis data available for report');
            return;
        }

        const reportContent = `
            <html>
            <head>
                <title>Network Analysis Report</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 40px; }
                    h1 { color: #333; }
                    .stat { margin: 20px 0; }
                    .anomaly { background: #f5f5f5; padding: 10px; margin: 5px 0; }
                </style>
            </head>
            <body>
                <h1>Network Packet Analysis Report</h1>
                <div class="stat">
                    <h3>Statistics</h3>
                    <p>Total Packets: ${currentAnalysisData.total_packets}</p>
                    <p>Anomalies Detected: ${currentAnalysisData.anomaly_count}</p>
                    <p>Anomaly Rate: ${currentAnalysisData.anomaly_rate.toFixed(2)}%</p>
                </div>
                <div class="anomalies">
                    <h3>Anomaly Breakdown</h3>
                    ${Object.entries(currentAnalysisData.anomaly_breakdown || {})
                        .map(([type, count]) => 
                            `<div class="anomaly">${type}: ${count} packets</div>`
                        ).join('')}
                </div>
                <p>Generated on: ${new Date().toLocaleString()}</p>
            </body>
            </html>
        `;

        const blob = new Blob([reportContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
        URL.revokeObjectURL(url);
    }

    function showError(message) {
        alert('Error: ' + message);
    }

    // Initialize with mock data for demonstration
    // Comment this out for production
    setTimeout(() => {
        // displayMockResults();
    }, 1000);
});