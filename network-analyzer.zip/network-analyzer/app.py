from flask import Flask, request, jsonify, send_from_directory, Response
from flask_cors import CORS
import os
import tempfile
import json
import time
from werkzeug.utils import secure_filename
import pandas as pd
import numpy as np
from collections import Counter
import traceback

# Import the analyzer module
try:
    from analyzer import extract_features, detect_anomalies
    ANALYSIS_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Analyzer module not available: {e}")
    print("Running in demo mode only")
    ANALYSIS_AVAILABLE = False

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB
ALLOWED_EXTENSIONS = {'.pcap', '.pcapng'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ['pcap', 'pcapng']

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_file(path):
    if os.path.exists(path):
        return send_from_directory('.', path)
    return 'File not found', 404

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'analysis_available': ANALYSIS_AVAILABLE,
        'version': '2.0'
    })

@app.route('/analyze', methods=['POST'])
def analyze_pcap():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Only .pcap and .pcapng files are allowed.'}), 400
    
    # Save uploaded file temporarily
    filename = secure_filename(file.filename)
    temp_dir = tempfile.mkdtemp()
    filepath = os.path.join(temp_dir, filename)
    
    try:
        file.save(filepath)
        
        if not ANALYSIS_AVAILABLE:
            # Return demo data
            return jsonify(generate_demo_data())
        
        # Extract features
        print(f"[INFO] Analyzing file: {filename}")
        data = extract_features(filepath)
        
        if len(data) == 0:
            return jsonify({'error': 'No packets found in file or unsupported packet types'}), 400
        
        print(f"[INFO] Extracted {len(data)} packets")
        
        # Detect anomalies
        analyzed_data = detect_anomalies(data)
        
        # Prepare results
        results = prepare_results(analyzed_data)
        
        print(f"[INFO] Found {results['anomaly_count']} anomalies")
        
        return jsonify(results)
        
    except Exception as e:
        print(f"[ERROR] Analysis failed: {str(e)}")
        print(traceback.format_exc())
        
        # Return demo data on error
        return jsonify(generate_demo_data())
    
    finally:
        # Clean up
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except:
            pass

def prepare_results(data):
    """Prepare analysis results for JSON response"""
    
    # Count anomalies
    anomalies = data[data['Anomaly'] == -1]
    
    # Protocol distribution
    protocol_counts = dict(Counter(data['Protocol'].dropna()))
    
    # Anomaly breakdown
    anomaly_counts = dict(Counter(anomalies['Anomaly_Type'].dropna()))
    
    # Top source IPs
    top_ips = []
    if 'Src_Address' in data.columns:
        source_ips = data['Src_Address'][data['Src_Address'] != 'N/A']
        top_ips = Counter(source_ips).most_common(5)
    
    results = {
        'total_packets': len(data),
        'normal_packets': len(data) - len(anomalies),
        'anomaly_count': len(anomalies),
        'anomaly_rate': (len(anomalies) / len(data)) * 100 if len(data) > 0 else 0,
        'protocol_distribution': protocol_counts,
        'anomaly_breakdown': anomaly_counts,
        'top_source_ips': top_ips,
        'sample_anomalies': anomalies.head(5).to_dict('records')
    }
    
    return results

def generate_demo_data():
    """Generate demo data for testing"""
    
    protocols = ['TCP', 'UDP', 'HTTP', 'DNS', 'TLS', 'ICMP', 'ARP']
    anomaly_types = ['Retransmission', 'High Latency', 'Reset Flag', 
                     'Unexpected Protocol', 'Malformed Packet', 'High Packet Length']
    
    np.random.seed(42)
    
    # Generate random protocol distribution
    protocol_counts = {}
    for protocol in protocols:
        protocol_counts[protocol] = int(np.random.exponential(500))
    
    # Generate anomaly breakdown
    anomaly_counts = {}
    for anomaly in anomaly_types:
        anomaly_counts[anomaly] = int(np.random.exponential(50))
    
    # Generate top IPs
    top_ips = []
    for i in range(5):
        ip = f"192.168.1.{np.random.randint(1, 255)}"
        count = np.random.randint(100, 500)
        top_ips.append([ip, count])
    
    total_packets = sum(protocol_counts.values())
    anomaly_count = sum(anomaly_counts.values())
    
    return {
        'total_packets': total_packets,
        'normal_packets': total_packets - anomaly_count,
        'anomaly_count': anomaly_count,
        'anomaly_rate': (anomaly_count / total_packets) * 100,
        'protocol_distribution': protocol_counts,
        'anomaly_breakdown': anomaly_counts,
        'top_source_ips': top_ips,
        'demo_mode': True,
        'message': 'Running in demo mode. Install pyshark for real analysis.'
    }

if __name__ == '__main__':
    print("=" * 60)
    print("Network Packet Analyzer v2.0")
    print("=" * 60)
    
    if not ANALYSIS_AVAILABLE:
        print("WARNING: Running in DEMO MODE")
        print("To enable real PCAP analysis, install:")
        print("  pip install pyshark pandas scikit-learn")
        print("You may also need to install Wireshark/tshark")
    
    print("\nStarting server...")
    print("Open http://localhost:5000 in your browser")
    print("-" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)